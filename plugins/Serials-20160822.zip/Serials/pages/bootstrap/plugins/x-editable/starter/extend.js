	<!-- momentjs -->
    <script src="http://vitalets.github.com/x-editable/assets/momentjs/moment.min.js"></script>

    <!-- select2 -->
    <link href="http://vitalets.github.com/x-editable/assets/select2/select2.css" rel="stylesheet">
    <script src="http://vitalets.github.com/x-editable/assets/select2/select2.js"></script>
    <!-- select2 bootstrap -->
    <link href="http://vitalets.github.com/x-editable/assets/select2/select2-bootstrap.css" rel="stylesheet">

    <!-- bootstrap-datetimepicker -->
    <link href="http://vitalets.github.com/x-editable/blob/gh-pages/assets/bootstrap-datetimepicker/css/datetimepicker.css" rel="stylesheet">
    <script src="http://vitalets.github.com/x-editable/blob/gh-pages/assets/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>