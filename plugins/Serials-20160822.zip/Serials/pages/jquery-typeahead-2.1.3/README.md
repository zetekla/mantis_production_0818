jQuery Typeahead
======================

The jQuery Typeahead plugin provides autocomplete preview on search inputs similar to google search with builtin options and deep customization.
It is a simple clientside library that will improve the user experience on your website search input!

The jQuery Typeahead plugin is released under the MIT License.

The complete documentation, demo and further instructions can be found at www.runningcoder.org

Documentation
======================

www.runningcoder.org/jquerytypeahead/documentation/

Demos
======================

www.runningcoder.org/jquerytypeahead/demo/

Version Notes
======================

www.runningcoder.org/jquerytypeahead/version/