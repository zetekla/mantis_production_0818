<style type="text/css">

span.serials-question	{  }
span.serials-date		{ font-style: italic; font-size: 8pt; }
td.serials-heading		{ background-color: #d8d8d8; color: #000000; text-align: left; border-bottom: 1px solid #000000; }
td.serials-body	    	{ background-color: #ffffff>; color: #000000; padding: 16pt; }

}
</style>
